package com.kzq.advance.domain.vo;

public class Orders {

    String adjust_fee;
    String buyer_rate;
    String cid;
    String consign_time;
    String discount_fee;
    String divide_order_fee;
    String end_time;
    String invoice_no;
    String is_daixiao;


    String logistics_company;
    String num;
    String num_iid;
    String oid;
    String outer_iid;
    String outer_sku_id;
    String payment;
    String pic_path;
    String price;

    String refund_status;
    String seller_rate;
    String seller_type;
    String shipping_type;
    String sku_id;
    String sku_properties_name;
    String status;
    String title;
    String total_fee;

    public String getAdjust_fee() {
        return adjust_fee;
    }

    public void setAdjust_fee(String adjust_fee) {
        this.adjust_fee = adjust_fee;
    }

    public String getBuyer_rate() {
        return buyer_rate;
    }

    public void setBuyer_rate(String buyer_rate) {
        this.buyer_rate = buyer_rate;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getConsign_time() {
        return consign_time;
    }

    public void setConsign_time(String consign_time) {
        this.consign_time = consign_time;
    }

    public String getDiscount_fee() {
        return discount_fee;
    }

    public void setDiscount_fee(String discount_fee) {
        this.discount_fee = discount_fee;
    }

    public String getDivide_order_fee() {
        return divide_order_fee;
    }

    public void setDivide_order_fee(String divide_order_fee) {
        this.divide_order_fee = divide_order_fee;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public String getInvoice_no() {
        return invoice_no;
    }

    public void setInvoice_no(String invoice_no) {
        this.invoice_no = invoice_no;
    }

    public String getIs_daixiao() {
        return is_daixiao;
    }

    public void setIs_daixiao(String is_daixiao) {
        this.is_daixiao = is_daixiao;
    }

    public String getLogistics_company() {
        return logistics_company;
    }

    public void setLogistics_company(String logistics_company) {
        this.logistics_company = logistics_company;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getNum_iid() {
        return num_iid;
    }

    public void setNum_iid(String num_iid) {
        this.num_iid = num_iid;
    }

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public String getOuter_iid() {
        return outer_iid;
    }

    public void setOuter_iid(String outer_iid) {
        this.outer_iid = outer_iid;
    }

    public String getOuter_sku_id() {
        return outer_sku_id;
    }

    public void setOuter_sku_id(String outer_sku_id) {
        this.outer_sku_id = outer_sku_id;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getPic_path() {
        return pic_path;
    }

    public void setPic_path(String pic_path) {
        this.pic_path = pic_path;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getRefund_status() {
        return refund_status;
    }

    public void setRefund_status(String refund_status) {
        this.refund_status = refund_status;
    }

    public String getSeller_rate() {
        return seller_rate;
    }

    public void setSeller_rate(String seller_rate) {
        this.seller_rate = seller_rate;
    }

    public String getSeller_type() {
        return seller_type;
    }

    public void setSeller_type(String seller_type) {
        this.seller_type = seller_type;
    }

    public String getShipping_type() {
        return shipping_type;
    }

    public void setShipping_type(String shipping_type) {
        this.shipping_type = shipping_type;
    }

    public String getSku_id() {
        return sku_id;
    }

    public void setSku_id(String sku_id) {
        this.sku_id = sku_id;
    }

    public String getSku_properties_name() {
        return sku_properties_name;
    }

    public void setSku_properties_name(String sku_properties_name) {
        this.sku_properties_name = sku_properties_name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(String total_fee) {
        this.total_fee = total_fee;
    }
}
